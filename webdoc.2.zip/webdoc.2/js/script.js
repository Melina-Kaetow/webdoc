/* Play/Pause HTML Video Based on Visibility / event listener/ video hvem er vi*/
var hvemervisektion = document.getElementById("hvemervivideo");
document.addEventListener("scroll", function myFunction() {
  if (
    hvemervisektion.getBoundingClientRect().bottom < 400 ||
    hvemervisektion.getBoundingClientRect().top > 300
  )
    hvemervisektion.pause();
  else hvemervisektion.play();
});
/* Play/Pause HTML Video Based on Visibility / event listener/ video hvem er du  */
var hvemerdusektion = document.getElementById("hvemerduvideo");
document.addEventListener("scroll", function myFunction() {
  if (
    hvemerdusektion.getBoundingClientRect().bottom < 400 ||
    hvemerdusektion.getBoundingClientRect().top > 400
  )
    hvemerdusektion.pause();
  else hvemerdusektion.play();
});

/* ---------- talebobbel 1 TYPEWRITER EFFEKT---------- */
const typedTextSpan = document.querySelector(".typed-text");
const cursorSpan = document.querySelector(".cursor");
/*definere variabler til typewriter effekten i taleboble*/
const textArray = [
  "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor. ",
];
const typingDelay = 80; // Delay before typing the next character
const newTextDelay = 1000; // Delay to start writing text
let textArrayIndex = 0;
let charIndex = 0;
/*typing funktion*/
function type() {
  if (charIndex < textArray[textArrayIndex].length) {
    if (!cursorSpan.classList.contains("typing"))
      cursorSpan.classList.add("typing");
    typedTextSpan.textContent += textArray[textArrayIndex].charAt(charIndex);
    charIndex++;
    setTimeout(type, typingDelay);
  } else {
    cursorSpan.classList.remove("typing");
  }
}
document.addEventListener("DOMContentLoaded", function () {
  // På DOM Load starter type writer effekten
  if (textArray.length) setTimeout(type, newTextDelay + 250);
});
/* ---------------------------------- */
/* ---------- talebobbel 2  TYPEWRITER EFFEKT---------- */
const typedTextSpan2 = document.querySelector(".typed-text2");
const cursorSpan2 = document.querySelector(".cursor2");
/*definere variabler til typewriter effekten i taleboble*/
const textArray2 = [
  "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor. ",
];
const typingDelay2 = 80; // Delay before typing the next character
const newTextDelay2 = 1000; // Delay to start writing text
let textArrayIndex2 = 0;
let charIndex2 = 0;
/*typing funktion*/
function type2() {
  if (charIndex2 < textArray2[textArrayIndex2].length) {
    if (!cursorSpan2.classList.contains("typing2"))
      cursorSpan2.classList.add("typing2");
    typedTextSpan2.textContent += textArray2[textArrayIndex2].charAt(
      charIndex2
    );
    charIndex2++;
    setTimeout(type2, typingDelay2);
  } else {
    cursorSpan2.classList.remove("typing2");
  }
}
document.addEventListener("DOMContentLoaded", function () {
  // På DOM Load starter type writer effekten
  if (textArray2.length) setTimeout(type2, newTextDelay2 + 15000);
});
/* ---------------------------------- */
/* -------- parallax baggrund ------- */
window.addEventListener("scroll", function () {
  var scrollPosition = window.pageYOffset;
  var bgParallax = document.getElementsByClassName("parallax")[0];
  var limit = bgParallax.offsetTop + bgParallax.offsetHeight;
  if (scrollPosition > bgParallax.offsetTop && scrollPosition <= limit) {
    bgParallax.style.backgroundPositionY = scrollPosition / 6 + "px";
  } else {
    bgParallax.style.backgroundPositionY = "0";
  }
});

/* ---------------------------------- */
/* -------- smooth scroll ------- 
const body = document.body,
  scrollWrap = document.getElementsByClassName("smooth-scroll-wrapper")[0],
  height = scrollWrap.getBoundingClientRect().height - 1,
  speed = 0.04;

var offset = 0;

body.style.height = Math.floor(height) + "px";

function smoothScroll() {
  offset += (window.pageYOffset - offset) * speed;

  var scroll = "translateY(-" + offset + "px) translateZ(0)";
  scrollWrap.style.transform = scroll;

  callScroll = requestAnimationFrame(smoothScroll);
}

smoothScroll();
*/
